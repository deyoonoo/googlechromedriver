from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common import exceptions
from flask import Flask, url_for, request, redirect, jsonify
from markupsafe import escape
import time, random, platform
from pyvirtualdisplay import Display 

app = Flask(__name__)

@app.route('/')
def hello_world():
    return jsonify({
                "status": True,
                "message": "Hi"
            })

@app.route('/user/<username>')
def profile(username):
    try:
        data_followers = scrape(username)
        if data_followers:
            return jsonify({
                    "status": True,
                    "username": username,
                    "followers": data_followers['followers'],
                    "isAbbreviated": data_followers['isAbbreviated'],
                    "profile_pic": data_followers['profile_pic']
                })
        else:
            return jsonify({
                "status": False,
                "message": "Error Scrape"
            })
    except Exception as e:
        return jsonify({
                "status": False,
                "message": "Error Runtime"
            })

# browser wrapper
def chrome_browser():
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument('--window-size=1920,1080')
    chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    chrome_options.add_experimental_option('prefs', {
        'credentials_enable_service': False,
        'profile': {
            'password_manager_enabled': False
        },
        "profile.default_content_setting_values.notifications" : 2
    })
    # chrome_options.add_argument('--headless') # hide the automated window
    chrome_options.add_argument('--no-sandbox') # required when running as root user. otherwise you would get no sandbox errors. 
    chrome_options.add_argument('--disable-blink-features=AutomationControlled')
    chrome_options.add_argument('--start-maximized')
    driver = webdriver.Chrome(options=chrome_options)
    return driver

def scrape(username='admiralbulldog'):
    if 'Linux' in platform.system():
        display = Display(visible=0, size=(1920, 1080))
        display.start()
    try:
        # initialize chrome browser
        browser = chrome_browser()
        # open twitch url
        browser.get(f'https://www.twitch.tv/{username}/about'.lower())
        browser.implicitly_wait(5)
        time.sleep(2)
        followers = browser.find_element_by_css_selector('.social-media-space--content div.tw-align-center').text
        try:
            profile_pic = browser.find_element_by_css_selector('.social-media-space img').get_attribute('src')
            profile_pic = profile_pic.replace('300', '600')
        except Exception as e:
            profile_pic = 'Not found'
        # convert the followers string into decimal
        data_number = followers.lower().split(' ', 1)[0]
        if 'k' in data_number:
            data_number = int(float(data_number.replace('k', ''))*1000)
            isAbbreviated = True
        elif 'm' in data_number:
            data_number = int(float(data_number.replace('m', ''))*1000*1000)
            isAbbreviated = True
        else:
            data_number = int(data_number)
            isAbbreviated = False
        return {
            "followers": data_number,
            "isAbbreviated": isAbbreviated,
            "profile_pic": profile_pic
        }
    except Exception as e:
        return False
    finally:
        browser.quit()
        if 'Linux' in platform.system():
            display.stop()

if __name__ == "__main__":
    app.run(host='0.0.0.0')